import React from 'react'
import Task1 from '../pages/Task1'
import Task2 from '../pages/Task2'


const indexRoutes = [
    { path: '/task1', component: <Task1 /> },
    // { path: '/task2', component: Task2 },

]

export default indexRoutes